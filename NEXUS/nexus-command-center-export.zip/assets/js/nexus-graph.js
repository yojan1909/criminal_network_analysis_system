/**
 * Nexus Intelligence Command Center - Interactive Network Graph Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  const svg = document.querySelector('main svg[viewBox="0 0 760 520"]');
  if (!svg) return;

  // Node entity dataset
  const entityData = {
    'Dmitri Petrov': {
      id: 'POI-9042',
      type: 'PERSON',
      role: 'Core Transshipment Coordinator',
      centrality: '0.94 (Top 1% Network Hub)',
      connections: 28,
      risk: 'CRITICAL THREAT (94/100)',
      color: '#4cd7f6',
      aliases: ['The Architect', 'D. Voronin'],
      status: 'Active Surveillance / INTERPOL Red Notice Pending',
      relSummary: 'Direct financial conduit between Limassol maritime freight and Baltic-X accounts'
    },
    'Limassol Port Terminal': {
      id: 'LOC-4011',
      type: 'LOCATION',
      role: 'Transshipment Hub (Cyprus)',
      centrality: '0.82 (Major Choke Point)',
      connections: 16,
      risk: 'HIGH PRIORITY (82/100)',
      color: '#10b981',
      aliases: ['Berth 4-B', 'Pier Seven Depot'],
      status: 'Monitored Port Authority Feed',
      relSummary: 'Co-location point for 4 flagged cargo vessels in past 90 days'
    },
    'Vektor Logistics': {
      id: 'ORG-5519',
      type: 'ORGANIZATION',
      role: 'Shell Freight Forwarder',
      centrality: '0.78 (Key Intermediary)',
      connections: 22,
      risk: 'HIGH PRIORITY (88/100)',
      color: '#c084fc',
      aliases: ['Vektor Maritime GMBH', 'VK Shipping'],
      status: 'Subpoena Served / Accounts Frozen',
      relSummary: 'Facilitated €1.4M in structured wire transfers via Cyprus & BVI'
    },
    'Baltic-X Holding': {
      id: 'ORG-6023',
      type: 'ORGANIZATION',
      role: 'Offshore Holding Vehicle',
      centrality: '0.75 (Financial Bridge)',
      connections: 14,
      risk: 'HIGH PRIORITY (85/100)',
      color: '#c084fc',
      aliases: ['Baltic Trade LLC'],
      status: 'Jurisdictional Mutual Legal Assistance Requested',
      relSummary: 'Beneficial ownership tracing points directly to Dmitri Petrov'
    },
    'Elena Rostova': {
      id: 'POI-3318',
      type: 'PERSON',
      role: 'Financial Trustee / Escrow Handler',
      centrality: '0.68 (Direct Courier)',
      connections: 9,
      risk: 'MEDIUM ALERT (68/100)',
      color: '#4cd7f6',
      aliases: ['E. Volkova'],
      status: 'Active Wiretap Warrant',
      relSummary: 'Authorized signatory on 3 secondary shell accounts'
    }
  };

  // 1. Make nodes interactive
  const circles = svg.querySelectorAll('circle');
  circles.forEach(circle => {
    circle.setAttribute('cursor', 'pointer');
    
    // Find nearby text
    const cx = parseFloat(circle.getAttribute('cx') || 0);
    const cy = parseFloat(circle.getAttribute('cy') || 0);
    const r = parseFloat(circle.getAttribute('r') || 0);
    
    // Skip small aesthetic or background dots
    if (r < 6) return;

    circle.addEventListener('mouseenter', () => {
      circle.style.transition = 'all 0.2s ease';
      circle.style.filter = 'drop-shadow(0 0 10px #4cd7f6)';
    });

    circle.addEventListener('mouseleave', () => {
      if (circle.getAttribute('data-selected') !== 'true') {
        circle.style.filter = '';
      }
    });

    circle.addEventListener('click', () => {
      // Clear previous selection
      circles.forEach(c => {
        c.removeAttribute('data-selected');
        c.style.stroke = '';
        c.style.strokeWidth = '';
      });

      // Highlight selected
      circle.setAttribute('data-selected', 'true');
      circle.style.stroke = '#ffffff';
      circle.style.strokeWidth = '3px';
      circle.style.filter = 'drop-shadow(0 0 14px #4cd7f6)';

      // Determine entity name from adjacent text or pick top match
      let matchedName = 'Dmitri Petrov';
      const allTexts = svg.querySelectorAll('text');
      let minDistance = 99999;
      allTexts.forEach(t => {
        const tx = parseFloat(t.getAttribute('x') || 0);
        const ty = parseFloat(t.getAttribute('y') || 0);
        const dist = Math.hypot(cx - tx, cy - ty);
        if (dist < minDistance && entityData[t.textContent.trim()]) {
          minDistance = dist;
          matchedName = t.textContent.trim();
        }
      });

      updateDetailDrawer(matchedName);
    });
  });

  function updateDetailDrawer(name) {
    const data = entityData[name] || entityData['Dmitri Petrov'];
    
    // Find drawer elements if present
    const nameEl = document.querySelector('[data-detail-name]');
    const typeEl = document.querySelector('[data-detail-type]');
    const idEl = document.querySelector('[data-detail-id]');
    const centralityEl = document.querySelector('[data-detail-centrality]');
    const riskEl = document.querySelector('[data-detail-risk]');
    const profileLink = document.querySelector('[data-detail-profile-link]');

    if (nameEl) nameEl.textContent = name;
    if (typeEl) typeEl.textContent = data.type;
    if (idEl) idEl.textContent = data.id;
    if (centralityEl) centralityEl.textContent = data.centrality;
    if (riskEl) riskEl.textContent = data.risk;
    if (profileLink) profileLink.href = 'entity-profiles.html';

    if (window.showTacticalToast) {
      window.showTacticalToast(`Target Selected: ${name} (${data.id})`, 'info');
    }
  }

  // 2. Zoom Controls
  let zoomLevel = 1.0;
  const zoomInBtn = document.querySelector('[data-zoom-in]');
  const zoomOutBtn = document.querySelector('[data-zoom-out]');
  const zoomResetBtn = document.querySelector('[data-zoom-reset]');

  if (zoomInBtn && svg) {
    zoomInBtn.addEventListener('click', () => {
      zoomLevel = Math.min(zoomLevel + 0.2, 2.5);
      applyZoom();
    });
  }
  if (zoomOutBtn && svg) {
    zoomOutBtn.addEventListener('click', () => {
      zoomLevel = Math.max(zoomLevel - 0.2, 0.6);
      applyZoom();
    });
  }
  if (zoomResetBtn && svg) {
    zoomResetBtn.addEventListener('click', () => {
      zoomLevel = 1.0;
      applyZoom();
    });
  }

  function applyZoom() {
    svg.style.transition = 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)';
    svg.style.transform = `scale(${zoomLevel})`;
    svg.style.transformOrigin = 'center center';
  }

  // 3. Entity filter checkboxes
  const filterCheckboxes = document.querySelectorAll('[data-entity-filter]');
  filterCheckboxes.forEach(cb => {
    cb.addEventListener('change', () => {
      const entityType = cb.getAttribute('data-entity-filter');
      const isChecked = cb.checked;
      if (window.showTacticalToast) {
        window.showTacticalToast(`Filter: ${entityType} ${isChecked ? 'Visible' : 'Hidden'}`, 'info');
      }
    });
  });

  // 4. Analysis buttons
  document.querySelectorAll('button').forEach(btn => {
    const txt = btn.textContent.trim();
    if (txt.includes('Key Influencers')) {
      btn.addEventListener('click', () => {
        if (window.showTacticalToast) {
          window.showTacticalToast('Centrality Algorithm: Dmitri Petrov & Limassol Terminal highlighted (eigenvector score > 0.85)', 'warning');
        }
      });
    } else if (txt.includes('Community Detection')) {
      btn.addEventListener('click', () => {
        if (window.showTacticalToast) {
          window.showTacticalToast('Louvain Community Detection: 3 clusters identified (Baltic Logistics, Cyprus Offshore, Frankfurt Escrow)', 'info');
        }
      });
    }
  });
});
