/**
 * Nexus Intelligence Command Center - Core Frontend Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Live Tactical UTC Clock
  const clockEl = document.getElementById('tactical-clock');
  function updateClock() {
    if (!clockEl) return;
    const now = new Date();
    const utcHours = String(now.getUTCHours()).padStart(2, '0');
    const utcMins = String(now.getUTCMinutes()).padStart(2, '0');
    const utcSecs = String(now.getUTCSeconds()).padStart(2, '0');
    clockEl.textContent = `${utcHours}:${utcMins}:${utcSecs} UTC`;
  }
  if (clockEl) {
    updateClock();
    setInterval(updateClock, 1000);
  }

  // 2. Global Hotkeys (/ or Cmd/Ctrl+K) for Search
  window.addEventListener('keydown', (e) => {
    if ((e.key === '/' || (e.key === 'k' && (e.metaKey || e.ctrlKey))) && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      const currentPath = window.location.pathname;
      if (!currentPath.includes('cross-case-search')) {
        window.location.href = 'cross-case-search.html';
      } else {
        const searchInput = document.querySelector('input[type="text"], input[type="search"]');
        if (searchInput) searchInput.focus();
      }
    }
  });

  // 3. Tactical Toast Notification Utility
  window.showTacticalToast = function(message, type = 'info') {
    let container = document.getElementById('nexus-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'nexus-toast-container';
      container.className = 'fixed bottom-4 right-4 z-50 flex flex-col gap-2 pointer-events-none';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    const borderColor = type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : type === 'error' ? '#ef4444' : '#06b6d4';
    toast.className = 'pointer-events-auto px-4 py-2.5 rounded-lg bg-[#141a21] border text-xs font-mono text-slate-200 shadow-xl flex items-center gap-2 transform translate-y-2 opacity-0 transition-all duration-300';
    toast.style.borderColor = borderColor;
    toast.innerHTML = `
      <span class="w-2 h-2 rounded-full" style="background-color: ${borderColor}"></span>
      <span>${message}</span>
    `;
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    }, 10);
    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  };

  // 4. Alerts & Pattern Intelligence Controller
  initAlertsPage();

  // 5. Report Generator Live Preview Controller
  initReportGenerator();

  // 6. Entity Profile & Case Workspace Tabs Controller
  initTabsNavigation();

  // 7. General Simulated Action Buttons
  document.querySelectorAll('button').forEach(btn => {
    const text = btn.textContent.trim();
    if (text.includes('Re-Index Feeds')) {
      btn.addEventListener('click', () => {
        window.showTacticalToast('Re-indexing federated intelligence nodes... Done [18ms]', 'success');
      });
    } else if (text.includes('Briefing Pack')) {
      btn.addEventListener('click', () => {
        window.showTacticalToast('Compiling 24hr Tactical Briefing Pack...', 'info');
        setTimeout(() => window.location.href = 'report-generator.html', 800);
      });
    } else if (text.includes('Acknowledge Filtered')) {
      btn.addEventListener('click', () => {
        window.showTacticalToast('All visible heuristic alerts acknowledged by Analyst M. Vance.', 'success');
      });
    } else if (text.includes('Export Threat Log')) {
      btn.addEventListener('click', () => {
        window.showTacticalToast('Threat Log CSV compiled and downloaded (18 records).', 'info');
      });
    } else if (text.includes('Save Query to Case') || text.includes('Bookmark')) {
      btn.addEventListener('click', () => {
        window.showTacticalToast('Query and filter pipeline saved to Case CS-2024-8841.', 'success');
      });
    }
  });
});

/**
 * Controller for Alerts & Patterns Page
 */
function initAlertsPage() {
  const articles = document.querySelectorAll('main article');
  if (articles.length === 0) return;

  const dossierTitle = document.querySelector('aside.xl\\:col-span-5 h3, aside[class*="col-span"] h3');
  const dossierCase = document.querySelector('aside.xl\\:col-span-5 span.text-primary, aside[class*="col-span"] span.text-primary');

  // Handle "Review Evidence" clicks
  articles.forEach(art => {
    const reviewBtn = art.querySelector('button:has(span.material-symbols-outlined)');
    const buttons = art.querySelectorAll('button');
    buttons.forEach(b => {
      if (b.textContent.includes('Review Evidence') || b.textContent.includes('Evidence Panel Active')) {
        b.addEventListener('click', (e) => {
          e.preventDefault();
          // Highlight card
          articles.forEach(a => {
            a.classList.remove('border-2', 'border-primary', 'shadow-lg');
            a.classList.add('border-outline-variant/30');
            const abtn = a.querySelector('button');
            if (abtn && abtn.textContent.includes('Evidence Panel Active')) {
              abtn.className = 'px-space-sm h-7 rounded bg-surface-container border border-outline-variant/40 hover:border-primary text-on-surface font-label-md text-label-md uppercase tracking-wider transition-colors flex items-center gap-1';
              abtn.innerHTML = '<span class=\"material-symbols-outlined text-[14px]\">readiness_score</span> Review Evidence';
            }
          });

          art.classList.add('border-2', 'border-primary', 'shadow-lg');
          art.classList.remove('border-outline-variant/30');
          b.className = 'px-space-sm h-7 rounded bg-primary text-on-primary font-label-md text-label-md uppercase tracking-wider font-bold flex items-center gap-1 shadow-sm';
          b.innerHTML = '<span class=\"material-symbols-outlined text-[15px]\">visibility</span> Evidence Panel Active';

          // Extract ID and Title
          const idEl = art.querySelector('.font-data-mono-sm.text-primary, .font-data-mono-sm.text-on-surface-variant');
          const titleEl = art.querySelector('h2');
          const alertId = idEl ? idEl.textContent.split('//')[0].trim() : 'ALT-8821';
          
          if (dossierTitle) {
            dossierTitle.textContent = `Evidence Dossier: ${alertId}`;
          }

          window.showTacticalToast(`Evidence Dossier loaded for ${alertId}`, 'info');
        });
      }
    });

    // Disposition dropdown handler
    const dispBtn = art.querySelector('button:has(span.material-symbols-outlined:contains("arrow_drop_down")), button[class*="text-body-sm"]:has(span.rounded-full)');
    if (dispBtn) {
      dispBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentText = dispBtn.textContent;
        if (currentText.includes('Pending Review')) {
          dispBtn.innerHTML = '<span class=\"w-2 h-2 rounded-full bg-emerald-400\"></span><span>Disposition: Confirmed</span><span class=\"material-symbols-outlined text-[14px] text-outline\">arrow_drop_down</span>';
          window.showTacticalToast('Disposition updated to: Confirmed Threat', 'success');
        } else if (currentText.includes('Confirmed')) {
          dispBtn.innerHTML = '<span class=\"w-2 h-2 rounded-full bg-rose-400\"></span><span>Disposition: False Positive</span><span class=\"material-symbols-outlined text-[14px] text-outline\">arrow_drop_down</span>';
          window.showTacticalToast('Disposition updated to: False Positive', 'warning');
        } else {
          dispBtn.innerHTML = '<span class=\"w-2 h-2 rounded-full bg-amber-400\"></span><span>Disposition: Pending Review</span><span class=\"material-symbols-outlined text-[14px] text-outline\">arrow_drop_down</span>';
          window.showTacticalToast('Disposition reset to: Pending Review', 'info');
        }
      });
    }
  });

  // Severity filter pills
  const severityPills = document.querySelectorAll('section button:has(span.animate-ping), section button:has(span.bg-amber-400), section button:has(span.bg-yellow-400), section button:has(span.bg-emerald-400)');
  severityPills.forEach(pill => {
    pill.addEventListener('click', () => {
      const text = pill.textContent.toUpperCase();
      let targetSev = '';
      if (text.includes('CRITICAL')) targetSev = 'CRITICAL';
      else if (text.includes('HIGH')) targetSev = 'HIGH';
      else if (text.includes('MEDIUM')) targetSev = 'MEDIUM';
      else if (text.includes('LOW')) targetSev = 'LOW';

      articles.forEach(art => {
        const artText = art.textContent.toUpperCase();
        if (targetSev && artText.includes(targetSev)) {
          art.style.display = '';
        } else {
          art.style.display = 'none';
        }
      });
      window.showTacticalToast(`Filtered alerts by: ${targetSev}`, 'info');
    });
  });

  // Search input filter in alerts
  const filterInput = document.querySelector('input[placeholder*="Filter pattern ID"]');
  if (filterInput) {
    filterInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      articles.forEach(art => {
        const text = art.textContent.toLowerCase();
        art.style.display = text.includes(q) ? '' : 'none';
      });
    });
  }
}

/**
 * Controller for Report Generator Page
 */
function initReportGenerator() {
  const checkboxes = document.querySelectorAll('main input[type=\"checkbox\"]');
  if (checkboxes.length === 0) return;

  const previewFrame = document.querySelector('main .bg-white, main [class*=\"bg-white\"]');
  if (!previewFrame) return;

  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => {
      const label = cb.closest('label') || cb.parentElement;
      const text = label ? label.textContent.trim() : '';
      window.showTacticalToast(`Report Section [${text.split('\n')[0].trim()}]: ${cb.checked ? 'Included' : 'Excluded'}`, 'info');
    });
  });
}

/**
 * Controller for Tabs Navigation on Entity Profiles & Case Workspaces
 */
function initTabsNavigation() {
  // Entity Profile Tabs
  const profileTabButtons = document.querySelectorAll('button:has(span.material-symbols-outlined + span)');
  profileTabButtons.forEach(btn => {
    const text = btn.textContent.trim();
    if (['Overview', 'Relationships', 'Timeline', 'Financials', 'Intercepts', 'Documents', 'Notes'].includes(text) || text.includes('Relationships')) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        // Update active styling
        btn.parentElement.querySelectorAll('button').forEach(b => {
          b.className = 'px-space-md py-2 rounded-lg hover:bg-surface-container text-on-surface-variant hover:text-on-surface font-headline-sm text-body-md flex items-center gap-2 transition-colors';
        });
        btn.className = 'px-space-md py-2 rounded-lg bg-surface-container text-primary font-headline-sm text-headline-sm font-bold flex items-center gap-2 shadow-sm';

        // Scroll to matching section if present
        if (text.includes('Relationships')) {
          const relSection = document.querySelector('section:has(table), table');
          if (relSection) relSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else if (text.includes('Timeline')) {
          const timeSection = document.querySelector('section:has(.timeline), div:has(> .border-l-2)');
          if (timeSection) timeSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else if (text.includes('Overview')) {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      });
    }
  });
}
